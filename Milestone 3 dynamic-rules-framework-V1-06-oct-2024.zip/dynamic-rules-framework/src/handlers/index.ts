import { EventHandlerAction } from "@src/event-handler/types";
import { EventParams, Policy } from "@src/types";
import { validateEventParams } from "@src/types/validate-types";
import { RuleResult, Event } from "json-rules-engine";

/**
 * If provided target and reference fact, it'll override the target fact
 * with the value of the reference fact on the given field.
 */
export const override: EventHandlerAction<Policy> = (
    event: Event,
    ruleResult: RuleResult,
    referenceFact: Policy,
    targetFact: Policy
) => {
    const params: EventParams = validateEventParams(event.params);

    if (!referenceFact || !targetFact) {
        console.log("Did not find reference or target fact.");
        return;
    }

    const key = params.fieldName as keyof Policy;

    // @ts-ignore
    targetFact[key] = referenceFact[key];
};

/**
 * If target fact has a list on the given field, and the list has a disabled attribute,
 * it'll set all those attributes as false, enabling them.
 */
export const enableAllChoices: EventHandlerAction<Policy> = (
    event: Event,
    ruleResult: RuleResult,
    referenceFact: Policy,
    targetFact: Policy
) => {
    const params: EventParams = validateEventParams(event);

    if (!targetFact) {
        console.log("Did not find target fact.");
    }

    const key = params.fieldName as keyof Policy;

    if (!Array.isArray(targetFact[key])) {
        console.log(`${params.fieldName} is not an array.`);
    }

    // @ts-ignore
    targetFact[key].forEach((choice: any) => {
        if (Object.hasOwn(choice, "disabled")) {
            choice.disabled = false;
        }
    });
};

/**
 * If target fact has a list on the given field, and the list has a disabled attribute,
 * it'll set all those attributes as true, disabling them.
 */
export const disableAllChoices: EventHandlerAction<Policy> = (
    event: Event,
    ruleResult: RuleResult,
    referenceFact: Policy,
    targetFact: Policy
) => {
    const params: EventParams = validateEventParams(event.params);

    if (!targetFact) {
        console.log("Did not find target fact.");
    }

    const key = params.fieldName as keyof Policy;

    if (!Array.isArray(targetFact[key])) {
        console.log(`${params.fieldName} is not an array.`);
    }

    // @ts-ignore
    targetFact[key].forEach((choice: any) => {
        if (Object.hasOwn(choice, "disabled")) {
            choice.disabled = true;
        }
    });
};
