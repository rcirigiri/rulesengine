import { EventType } from "@src/event-handler/event-type";
import { RuleResult } from "json-rules-engine";

export interface Policy {
    id: string;
    displayName: string;
    selected: boolean;
    termsId: string;
    termsDisplayName: string;
    availableChoices: AvailableChoice[];
    choiceValue: ChoiceValue;
    recommendedValue: RecommendedValue;
    covTermType: string;
    required: boolean;
}

export interface AvailableChoice {
    code: string;
    name: string;
    disabled: boolean;
}

export interface ChoiceValue {
    code: string;
    name: string;
}

export interface RecommendedValue {
    code: string;
    name: string;
}

export interface EventParams {
    eventType: EventType;
    message: string;
    targetFactSearch: FactSearchParams;
    referenceFactSearch: FactSearchParams;
    fieldName: string;
}

export interface FactSearchParams {
    searchValue: string | number;
    searchFieldName: string;
}

export interface RunOutput<T> {
    outputFacts: Array<T>;
    ruleResults: Array<RuleResult>;
}
