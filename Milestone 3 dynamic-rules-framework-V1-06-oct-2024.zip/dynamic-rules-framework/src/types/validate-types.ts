import { validateEventType } from "@src/event-handler/types/validate-types";
import { EventParams, FactSearchParams } from "@src/types";

/**
 * Function to validate if params is of type FactSearchParams
 * @param params any
 * @returns `FactSearchParams`
 */
export function validateFactSearchParams(params: any): FactSearchParams {
    if (
        !params ||
        (typeof params.searchValue !== "string" && typeof params.searchValue !== "number") ||
        typeof params.searchFieldName !== "string"
    ) {
        throw Error("Invalid FactSearchParams.");
    }

    return params as FactSearchParams;
}

/**
 * Function to validate if event.params is of type EventParams
 * @param params any
 * @returns `EventParams`
 */
export function validateEventParams(params: any): EventParams {
    if (!params || typeof params.message !== "string" || typeof params.fieldName !== "string") {
        throw new Error("Invalid EventParams.");
    }

    // Validate targetFact and referenceFact using the FactSearchParams validator
    validateFactSearchParams(params.targetFactSearch);
    validateFactSearchParams(params.referenceFactSearch);

    // Validate eventCode using the EventCode validator
    validateEventType(params.eventType);

    return params as EventParams;
}
