// First import has to be module alias
import "./utils/module-alias";

import { RuleProperties } from "json-rules-engine";
import { DynamicEngineBuilder } from "@src/dynamic-engine-builder";
import { Policy } from "@src/types";
import { writeJsonToFile } from "@src/utils/write-file";
import { EventHandlerRegistry } from "@src/event-handler/registry";
import { EventType } from "@src/event-handler/event-type";
import { disableAllChoices, enableAllChoices, override } from "@src/handlers";

// Data
import inputJson from "@data/input.json";
import rulesJson from "@data/rules.json";

const registry = new EventHandlerRegistry<Policy>();
registry.register(EventType.DoNothing, () => {});
registry.register(EventType.OverrideValue, override);
registry.register(EventType.DisableAllChoices, disableAllChoices);
registry.register(EventType.EnableAllChoices, enableAllChoices);

// prettier-ignore
DynamicEngineBuilder
    .createEngine<Policy>(registry)
    .addRules(<RuleProperties[]>rulesJson)
    .addFacts(<Policy[]>inputJson)
    .run()
    .then((output) => {
        writeJsonToFile(output.outputFacts, "./data/output.json");
        writeJsonToFile(output.ruleResults, "./data/rule-results.json");
    });
