import { EventType } from "@src/event-handler/event-type";

/**
 * Function to validate if params is of type FactSearchParams
 * @param eventType any
 * @returns `FactSearchParams`
 */
export function validateEventType(eventType: any): EventType | undefined {
    if (!Object.values(EventType).includes(eventType)) {
        throw Error("Invalid EventType.");
    }

    return eventType as EventType;
}
