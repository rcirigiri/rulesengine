import { Event, RuleResult } from "json-rules-engine";

export type EventHandlerAction<T extends Record<any, any>> = (
    event: Event,
    ruleResult: RuleResult,
    referenceFact: T,
    targetFact: T
) => void;
