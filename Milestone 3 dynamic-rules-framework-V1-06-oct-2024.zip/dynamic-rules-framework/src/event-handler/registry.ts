import { EventHandlerAction } from "@src/event-handler/types";
import { EventType } from "@src/event-handler/event-type";

class EventHandlerRegistry<T extends Record<any, any>> {
    private registryMap: Map<EventType, EventHandlerAction<T>>;

    public constructor() {
        this.registryMap = new Map<EventType, EventHandlerAction<T>>();
    }

    public register(key: EventType, handler: EventHandlerAction<T>): void {
        this.registryMap.set(key, handler);
    }

    public get(key: EventType): EventHandlerAction<T> | undefined {
        return this.registryMap.get(key);
    }
}

export { EventHandlerRegistry };
