export const EventType = {
    DoNothing: "nothing",
    OverrideValue: "override",
    EnableAllChoices: "enable-all-choices",
    DisableAllChoices: "disable-all-choices",
} as const;

export type EventType = (typeof EventType)[keyof typeof EventType];
