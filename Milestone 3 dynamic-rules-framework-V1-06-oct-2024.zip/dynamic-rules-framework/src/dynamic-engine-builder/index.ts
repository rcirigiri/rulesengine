import _ from "lodash";
import { Engine, Almanac, RuleResult, Event, RuleProperties } from "json-rules-engine";
import { log } from "console";

// Event Handler
import { EventHandlerRegistry } from "@src/event-handler/registry";

// Types
import { EventParams, FactSearchParams, RunOutput } from "@src/types";
import { validateEventParams, validateFactSearchParams } from "@src/types/validate-types";

class DynamicEngineBuilder<T extends Record<any, any>> {
    private engine: Engine;
    private facts: Array<T> | undefined;
    private outputFacts: Array<T> | undefined;
    private eventHandlerRegistry: EventHandlerRegistry<T> | undefined;

    private constructor(registry: EventHandlerRegistry<T>) {
        this.engine = new Engine();
        this.eventHandlerRegistry = registry;

        this.setupFactListeners();
        this.setupEventListeners();
    }

    private setupFactListeners(): void {
        this.engine.addFact("referenceFact", this.referenceFactHandler.bind(this));
        this.engine.addFact("targetFact", this.targetFactHandler.bind(this));
    }

    private setupEventListeners(): void {
        this.engine.on("failure", this.handle.bind(this));
        this.engine.on("success", this.handle.bind(this));
    }

    private referenceFactHandler(_params: Record<any, any>, _almanac: Almanac): T | undefined {
        const params: FactSearchParams = validateFactSearchParams(_params);
        return this.facts?.find((x) => {
            return _.get(x, params.searchFieldName) === params.searchValue;
        });
    }

    private targetFactHandler(_params: Record<any, any>, _almanac: Almanac): T | undefined {
        const params: FactSearchParams = validateFactSearchParams(_params);
        return this.outputFacts?.find((x) => {
            return _.get(x, params.searchFieldName) === params.searchValue;
        });
    }

    private findReferenceFact({ searchFieldName, searchValue }: FactSearchParams): T | undefined {
        return this.facts?.find((o) => {
            return _.get(o, searchFieldName) === searchValue;
        });
    }

    private findTargetFact({ searchFieldName, searchValue }: FactSearchParams): T | undefined {
        return this.outputFacts?.find((o) => {
            return _.get(o, searchFieldName) === searchValue;
        });
    }

    private handle(event: Event, _almanac: Almanac, ruleResult: RuleResult): void {
        const message = ruleResult.event?.params?.message ?? "No message provided.";
        const type = ruleResult.event?.type ?? "No type provided.";
        const params: EventParams = validateEventParams(event.params);
        const ruleFailed = ruleResult.result === false;

        log(`[${ruleFailed ? "FAIL" : "SUCCESS"}] (${type}) → ${message} : ${params.eventType}`);

        const referenceFact = this.findReferenceFact(params.referenceFactSearch);
        const targetFact = this.findTargetFact(params.targetFactSearch);

        const eventAction = this.eventHandlerRegistry?.get(params.eventType);

        if (eventAction && referenceFact && targetFact) {
            eventAction(event, ruleResult, referenceFact, targetFact);
        }
    }

    public static createEngine<T extends Record<any, any>>(registry: EventHandlerRegistry<T>) {
        return new DynamicEngineBuilder<T>(registry);
    }

    public addRules(rules: Array<RuleProperties>): this {
        for (const rule of rules) {
            this.engine.addRule(rule);
        }

        return this;
    }

    public addFacts(facts: Array<T>): this {
        this.facts = facts;
        this.outputFacts = facts;
        return this;
    }

    public async run(): Promise<RunOutput<T>> {
        if (!this.facts) {
            log("Facts undefined.");
            return { outputFacts: [], ruleResults: [] };
        }

        const engineResult = await this.engine.run(this.facts);

        return {
            outputFacts: this.outputFacts || [],
            ruleResults: [...engineResult.failureResults, ...engineResult.results],
        };
    }
}

export { DynamicEngineBuilder };
