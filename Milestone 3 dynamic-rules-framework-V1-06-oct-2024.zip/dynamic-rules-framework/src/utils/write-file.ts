import fs from "fs";

export function writeJsonToFile(json: Object, filePath: string) {
    if (Array.isArray(json)) {
        json = json.map((o) => JSON.parse(JSON.stringify(o)));
    }

    const jsonData = JSON.stringify(json, null, 4);

    fs.writeFile(filePath, jsonData, (error) => {
        if (error) {
            console.error("Error writing file:", error);
        } else {
            console.log("File has been written successfully!");
        }
    });
}
